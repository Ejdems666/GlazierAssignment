package app.model.entity;

/**
 * Created by Ejdems on 26/11/2016.
 */
public interface IEntity {
    public int getId();
    public void setId(int id);
}
