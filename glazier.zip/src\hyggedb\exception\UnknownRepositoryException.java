package hyggedb.exception;

/**
 * Created by Ejdems on 27/11/2016.
 */
public class UnknownRepositoryException extends Error {
}
