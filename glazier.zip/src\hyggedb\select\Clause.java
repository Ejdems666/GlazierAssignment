package hyggedb.select;

/**
 * Created by Ejdems on 16/11/2016.
 */
public interface Clause {
    String getClause();
}
